<?php
$motopress_cam_id = uniqid();

// WPML filter
$suppress_filters = get_option('suppress_filters');

// Get Order & Orderby Parameters
$orderby = (of_get_option('slider_posts_orderby')) ? of_get_option('slider_posts_orderby') : 'date';
$order = (of_get_option('slider_posts_order')) ? of_get_option('slider_posts_order') : 'DESC';

// query
$args = array(
    'post_type' => 'slider',
    'posts_per_page' => -1,
    'post_status' => 'publish',
    'orderby' => $orderby,
    'order' => $order,
    'suppress_filters' => $suppress_filters
);
$slides = get_posts($args);
if (empty($slides)) return;
?>


<script type="text/javascript">
    //    jQuery(window).load(function() {
    jQuery(function () {

        var _CaptionTransitions = [];
        _CaptionTransitions["D"] = {
            $Duration: 1200,
            $Zoom: 1,
            $Easing: {$Zoom: $JssorEasing$.$EaseInCubic, $Opacity: $JssorEasing$.$EaseOutQuad},
            $Opacity: 2
        }
        _CaptionTransitions["L"] = {
            $Duration: 900,
            x: 0.6,
            $Easing: {$Left: $JssorEasing$.$EaseInOutSine},
            $Opacity: 2
        };
        _CaptionTransitions["R"] = {
            $Duration: 900,
            x: -0.6,
            $Easing: {$Left: $JssorEasing$.$EaseInOutSine},
            $Opacity: 2
        };
        _CaptionTransitions["T"] = {$Duration: 900, y: 0.6, $Easing: {$Top: $JssorEasing$.$EaseInOutSine}, $Opacity: 2};
        _CaptionTransitions["B"] = {
            $Duration: 900,
            y: -0.6,
            $Easing: {$Top: $JssorEasing$.$EaseInOutSine},
            $Opacity: 2
        };
        _CaptionTransitions["ZMF|10"] = {
            $Duration: 900,
            $Zoom: 1,
            $Easing: {$Zoom: $JssorEasing$.$EaseOutQuad, $Opacity: $JssorEasing$.$EaseLinear},
            $Opacity: 2
        };
        _CaptionTransitions["RTT|10"] = {
            $Duration: 900,
            $Zoom: 11,
            $Rotate: 1,
            $Easing: {
                $Zoom: $JssorEasing$.$EaseOutQuad,
                $Opacity: $JssorEasing$.$EaseLinear,
                $Rotate: $JssorEasing$.$EaseInExpo
            },
            $Opacity: 2,
            $Round: {$Rotate: 0.8}
        };
        _CaptionTransitions["RTT|2"] = {
            $Duration: 900,
            $Zoom: 3,
            $Rotate: 1,
            $Easing: {
                $Zoom: $JssorEasing$.$EaseInQuad,
                $Opacity: $JssorEasing$.$EaseLinear,
                $Rotate: $JssorEasing$.$EaseInQuad
            },
            $Opacity: 2,
            $Round: {$Rotate: 0.5}
        };
        _CaptionTransitions["RTTL|BR"] = {
            $Duration: 900,
            x: -0.6,
            y: -0.6,
            $Zoom: 11,
            $Rotate: 1,
            $Easing: {
                $Left: $JssorEasing$.$EaseInCubic,
                $Top: $JssorEasing$.$EaseInCubic,
                $Zoom: $JssorEasing$.$EaseInCubic,
                $Opacity: $JssorEasing$.$EaseLinear,
                $Rotate: $JssorEasing$.$EaseInCubic
            },
            $Opacity: 2,
            $Round: {$Rotate: 0.8}
        };
        _CaptionTransitions["CLIP|LR"] = {
            $Duration: 900,
            $Clip: 15,
            $Easing: {$Clip: $JssorEasing$.$EaseInOutCubic},
            $Opacity: 2
        };
        _CaptionTransitions["MCLIP|L"] = {
            $Duration: 900,
            $Clip: 1,
            $Move: true,
            $Easing: {$Clip: $JssorEasing$.$EaseInOutCubic}
        };
        _CaptionTransitions["MCLIP|R"] = {
            $Duration: 900,
            $Clip: 2,
            $Move: true,
            $Easing: {$Clip: $JssorEasing$.$EaseInOutCubic}
        };

        var options = {
            $FillMode: 2,                                       //[Optional] The way to fill image in slide, 0 stretch, 1 contain (keep aspect ratio and put all inside slide), 2 cover (keep aspect ratio and cover whole slide), 4 actual size, 5 contain for large image, actual size for small image, default value is 0
            $AutoPlay: true,                                    //[Optional] Whether to auto play, to enable slideshow, this option must be set to true, default value is false
            $AutoPlayInterval: 4000,                            //[Optional] Interval (in milliseconds) to go for next slide since the previous stopped if the slider is auto playing, default value is 3000
            $PauseOnHover: 1,                                   //[Optional] Whether to pause when mouse over if a slider is auto playing, 0 no pause, 1 pause for desktop, 2 pause for touch device, 3 pause for desktop and touch device, 4 freeze for desktop, 8 freeze for touch device, 12 freeze for desktop and touch device, default value is 1

            $ArrowKeyNavigation: true,   			            //[Optional] Allows keyboard (arrow key) navigation or not, default value is false
            $SlideEasing: $JssorEasing$.$EaseOutQuint,          //[Optional] Specifies easing for right to left animation, default value is $JssorEasing$.$EaseOutQuad
            $SlideDuration: 1200,                               //[Optional] Specifies default duration (swipe) for slide in milliseconds, default value is 500
            $MinDragOffsetToSlide: 20,                          //[Optional] Minimum drag offset to trigger slide , default value is 20
            // TODO two lines(djzhang)
            //$SlideWidth: 600,                                 //[Optional] Width of every slide in pixels, default value is width of 'slides' container
            //$SlideHeight: 360,                                //[Optional] Height of every slide in pixels, default value is height of 'slides' container
            $SlideSpacing: 0, 					                //[Optional] Space between each slide in pixels, default value is 0
            $DisplayPieces: 1,                                  //[Optional] Number of pieces to display (the slideshow would be disabled if the value is set to greater than 1), the default value is 1
            $ParkingPosition: 0,                                //[Optional] The offset position to park slide (this options applys only when slideshow disabled), default value is 0.
            $UISearchMode: 1,                                   //[Optional] The way (0 parellel, 1 recursive, default value is 1) to search UI components (slides container, loading screen, navigator container, arrow navigator container, thumbnail navigator container etc).
            $PlayOrientation: 1,                                //[Optional] Orientation to play slide (for auto play, navigation), 1 horizental, 2 vertical, 5 horizental reverse, 6 vertical reverse, default value is 1
            $DragOrientation: 1,                                //[Optional] Orientation to drag slide, 0 no drag, 1 horizental, 2 vertical, 3 either, default value is 1 (Note that the $DragOrientation should be the same as $PlayOrientation when $DisplayPieces is greater than 1, or parking position is not 0)

            $CaptionSliderOptions: {                            //[Optional] Options which specifies how to animate caption
                $Class: $JssorCaptionSlider$,                   //[Required] Class to create instance to animate caption
                $CaptionTransitions: _CaptionTransitions,       //[Required] An array of caption transitions to play caption, see caption transition section at jssor slideshow transition builder
                $PlayInMode: 1,                                 //[Optional] 0 None (no play), 1 Chain (goes after main slide), 3 Chain Flatten (goes after main slide and flatten all caption animations), default value is 1
                $PlayOutMode: 3                                 //[Optional] 0 None (no play), 1 Chain (goes before main slide), 3 Chain Flatten (goes before main slide and flatten all caption animations), default value is 1
            },

            $BulletNavigatorOptions: {                          //[Optional] Options to specify and enable navigator or not
                $Class: $JssorBulletNavigator$,                 //[Required] Class to create navigator instance
                $ChanceToShow: 2,                               //[Required] 0 Never, 1 Mouse Over, 2 Always
                $AutoCenter: 1,                                 //[Optional] Auto center navigator in parent container, 0 None, 1 Horizontal, 2 Vertical, 3 Both, default value is 0
                $Steps: 1,                                      //[Optional] Steps to go for each navigation request, default value is 1
                $Lanes: 1,                                      //[Optional] Specify lanes to arrange items, default value is 1
                $SpacingX: 8,                                   //[Optional] Horizontal space between each item in pixel, default value is 0
                $SpacingY: 8,                                   //[Optional] Vertical space between each item in pixel, default value is 0
                $Orientation: 1                                 //[Optional] The orientation of the navigator, 1 horizontal, 2 vertical, default value is 1
            },

            $ArrowNavigatorOptions: {                           //[Optional] Options to specify and enable arrow navigator or not
                $Class: $JssorArrowNavigator$,                  //[Requried] Class to create arrow navigator instance
                $ChanceToShow: 1,                               //[Required] 0 Never, 1 Mouse Over, 2 Always
                $AutoCenter: 2,                                 //[Optional] Auto center arrows in parent container, 0 No, 1 Horizontal, 2 Vertical, 3 Both, default value is 0
                $Steps: 1                                       //[Optional] Steps to go for each navigation request, default value is 1
            }
        };

        var jssor_slider1 = new $JssorSlider$("slider1_container", options);

        //responsive code begin
        //you can remove responsive code if you don't want the slider scales while window resizes
        function ScaleSlider() {
            var bodyWidth = document.body.clientWidth;
            if (bodyWidth)
                jssor_slider1.$ScaleWidth(Math.min(bodyWidth, 1920));
            else
                window.setTimeout(ScaleSlider, 30);
        }

        ScaleSlider();

        $(window).bind("load", ScaleSlider);
        $(window).bind("resize", ScaleSlider);
        $(window).bind("orientationchange", ScaleSlider);
        //responsive code end
    });
    //    });
</script>


<div id="slider1_container"
     style="position: relative; margin: 0 auto;top: 0px; left: 0px; width: 1300px; height: 360px; overflow: hidden;">

    <!-- Slides Container -->
    <div u="slides"
         style="cursor: move; position: absolute; left: 0px; top: 0px; width: 1300px;height: 360px ; overflow: hidden;">


        <?php foreach ($slides as $k => $slide) {
            echo "<div style='width: auto; height: auto; display: none'>";// begin_div

            //Check if WPML is activated
            if (defined('ICL_SITEPRESS_VERSION')) {
                global $sitepress;

                $post_lang = $sitepress->get_language_for_element($slide->ID, 'post_slider');
                $curr_lang = $sitepress->get_current_language();
                // Unset not translated posts
                if ($post_lang != $curr_lang) {
                    unset($slides[$k]);
                }
                // Post ID is different in a second language Solution
                if (function_exists('icl_object_id')) {
                    $slide = get_post(icl_object_id($slide->ID, 'slider', true));
                }
            }

            $caption = get_post_meta($slide->ID, 'my_slider_caption', true);
            $url = get_post_meta($slide->ID, 'my_slider_url', true);
            $sl_image_url = wp_get_attachment_image_src(get_post_thumbnail_id($slide->ID), 'slider-post-thumbnail');

            $style_title1 = "position: absolute; width: 480px; height: 120px; top: 30px; left: 60px; padding: 5px;text-align: left; line-height: 60px; font-weight:bold; text-transform: uppercase; font-size: 40px;color: #F50D29";
            $style_title2 = "position: absolute; width: 480px; height: 120px; top: 80px; left: 60px; padding: 5px;text-align: left; line-height: 60px; font-weight:bold; text-transform: uppercase; font-size: 40px;color: #F50D29";
            $style_description = "position: absolute; width: 480px; height: 220px; top: 140px; left: 60px; padding: 5px;text-align: left; line-height: 26px; font-size: 12px;color: #777777;";


            echo "<div u='caption' t='ZMF|10' style='position: absolute; width: 200px; height: 200px; top: 60px; left: 700px;'>";
            echo "<img src='$sl_image_url[0]' style='position: absolute; width: 200px; height: 200px; top: 0px; left: 0px;'/>";
            echo "</div>";

            $replace = "style='{$style_title1}'";
            $content = str_replace("%title1%", $replace, $caption);
            $replace = "style='{$style_title2}'";
            $content = str_replace("%title2%", $replace, $content);
            $replace = "style='{$style_description}'";
            $content = str_replace("%description%", $replace, $content);


            $button_html_before01 = "style='position: absolute; bottom: 120px;left: 100px;'><a target='_self'  class='btn btn-primary btn-large btn-inline' title='Download' href='";
            $button_html_before02 = "'>Buy now - $";
            $button_html_after = "</a>";

            $replace = "{$button_html_before01}$url{$button_html_before02}";
            $content = str_replace("%button_before%", $replace, $content);
            $replace = "{$button_html_after}";
            $content = str_replace("%button_after%", $replace, $content);

            if ($caption) { ?>
                <?php echo stripslashes(htmlspecialchars_decode($content)); ?>
            <?php }

            echo "</div>";// end_div
        }

        wp_reset_postdata();
        ?>
    </div>

    <!-- bullet navigator container -->
    <!--    <div u="navigator" class="jssorb21" style="bottom: 26px; right: 6px;">-->
    <!-- bullet navigator item prototype -->
    <!--        <div u="prototype"></div>-->
    <!--    </div>-->
    <!--#endregion Bullet Navigator Skin End -->

    <!-- bullet navigator container -->
    <div u="navigator" class="jssorb05" style="bottom: 16px; right: 6px;">
        <!-- bullet navigator item prototype -->
        <div u="prototype"></div>
    </div>
    <!--#endregion Bullet Navigator Skin End -->

    <!-- Arrow Left -->
    <!--        <span u="arrowleft" class="jssora21l" style="top: 123px; left: 8px;"/>-->
    <!-- Arrow Right -->
    <!--        <span u="arrowright" class="jssora21r" style="top: 123px; right: 8px;"/>-->
    <!-- Arrow Left -->
    <!--    <span u="arrowleft" class="jssora13l" style="top: 123px; left: 10px;"/>-->
    <!-- Arrow Right -->
    <!--    <span u="arrowright" class="jssora13r" style="top: 123px; right: 300px;"/>-->

    <!-- Arrow Left -->
    <!--    <span u="arrowleft" class="jssora12l" style="top: 123px; left: 0px;"></span>-->
    <!-- Arrow Right -->
    <!--    <span u="arrowright" class="jssora12r" style="top: 123px; right: 200px;"></span>-->

</div>


